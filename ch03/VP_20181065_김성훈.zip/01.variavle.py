variable1 = 100
variable2 = 3.14
variable3 = -200
variable4 = 1.2 + 3.4j
variable5 = 'This is Python'

variable6 = True
variable7 = float(variable1)
variable8 = int(variable2)

print('variable 1 = ', variable1, type(variable1))
print('variable 2 = ', variable2, type(variable2))
print('variable 3 = ', variable3, type(variable3))
print('variable 4 = ', variable4, type(variable4))
print('variable 5 = ', variable5, type(variable5))
print('variable 6 = ', variable6, type(variable6))
print('variable 7 = ', variable7, type(variable7))
print('variable 8 = ', variable8, type(variable8))