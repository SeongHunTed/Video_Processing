n = 3
while n>=0:
    m = input("Enter a interger : ")
    if int(n) == 0:
        break
    n = n - 1
else:
    print("4 inputs")